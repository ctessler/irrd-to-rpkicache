/* $Id: bio_f_linebreak.h 4001 2011-09-24 15:49:03Z sra $ */

#ifndef __BIO_F_LINEBREAK__
#define __BIO_F_LINEBREAK__

#include <openssl/bio.h>

BIO_METHOD *BIO_f_linebreak(void);

#endif /* __BIO_F_LINEBREAK__ */
