#!/bin/sh -
# $Id: deinstall.sh 3660 2011-01-25 05:19:14Z sra $

echo Sorry, automated deinstallation of rcynic is not implemented yet
exit 1
