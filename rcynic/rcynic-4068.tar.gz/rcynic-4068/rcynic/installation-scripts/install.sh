#!/bin/sh -
# $Id: install.sh 3667 2011-01-26 04:33:08Z sra $

set -e

case "${host_os}" in

freebsd*) cd freebsd; . ./install.sh;;
darwin*)  cd darwin;  . ./install.sh;;
linux*)	  cd linux;   . ./install.sh;;

*)	echo 1>&2 "Don't know how to install rcynic jail on platform ${host_os}"
	exit 1;;
esac
