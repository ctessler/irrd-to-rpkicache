#!/bin/sh -
# $Id: mirror-apnic.sh 1434 2007-12-24 06:36:18Z sra $

# An unknown entity representing itself as gmm says that this is the
# trust anchor for the APNIC test repository.
#
fetch -m -o repository.apnic.net/trust-anchor.cer \
    http://mirin.apnic.net/resourcecerts/trust-anchor.cer

# Mirror the repository itself
#
rsync -aiz --delete rsync://repository.apnic.net/APNIC/ repository.apnic.net/APNIC/
